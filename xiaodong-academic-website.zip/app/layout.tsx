import type React from "react"
import type { Metadata } from "next"
import { Montserrat, Open_Sans, Roboto_Mono } from "next/font/google"
import "./globals.css"

const montserrat = Montserrat({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-montserrat",
  display: "swap",
})

const openSans = Open_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-open-sans",
  display: "swap",
})

const robotoMono = Roboto_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-roboto-mono",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Xiaodong Zhang - Academic Portfolio",
  description: "PhD Applicant | Metabolomics Application Scientist specializing in lipidomics and mass spectrometry",
  keywords: ["metabolomics", "lipidomics", "mass spectrometry", "natural products", "PhD applicant"],
  authors: [{ name: "Xiaodong Zhang" }],
  viewport: "width=device-width, initial-scale=1",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${montserrat.variable} ${openSans.variable} ${robotoMono.variable}`}>
      <body className="font-body antialiased">{children}</body>
    </html>
  )
}
