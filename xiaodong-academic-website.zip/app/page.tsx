"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Mail, Menu, X, ExternalLink, Phone, FlaskConical, BarChart3, Code } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function AcademicWebsite() {
  const [activeSection, setActiveSection] = useState("home")
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrollY, setScrollY] = useState(0)

  const navItems = [
    { id: "home", label: "HOME" },
    { id: "about", label: "ABOUT" },
    { id: "research", label: "RESEARCH" },
    { id: "publications", label: "PUBLICATIONS" },
    { id: "skills", label: "SKILLS" },
    { id: "contact", label: "CONTACT" },
  ]

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)

      const sections = navItems.map((item) => item.id)
      const currentSection = sections.find((section) => {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          return rect.top <= 100 && rect.bottom >= 100
        }
        return false
      })

      if (currentSection) {
        setActiveSection(currentSection)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsMenuOpen(false)
  }

  return (
    <div className="min-h-screen bg-[#1a1a1a] text-[#e1e1e1] font-body">
      {/* Navigation */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrollY > 50 ? "backdrop-blur-md bg-[#1a1a1a]/80 border-b border-[#4a90e2]/20" : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="font-bold text-xl">MYCROFT ZHANG</div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`text-sm font-medium transition-colors duration-200 hover:text-[#4a90e2] ${
                    activeSection === item.id ? "text-[#4a90e2]" : "text-[#e1e1e1]"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-[#1a1a1a]/95 backdrop-blur-md border-t border-[#4a90e2]/20">
            <div className="px-4 py-4 space-y-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`block w-full text-left text-sm font-medium transition-colors duration-200 hover:text-[#4a90e2] ${
                    activeSection === item.id ? "text-[#4a90e2]" : "text-[#e1e1e1]"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section - Two Column Layout */}
      <section id="home" className="min-h-screen flex items-center relative overflow-hidden">
        {/* Molecular Background Animation */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-1/4 left-1/4 w-8 h-8 border border-[#4a90e2] rounded-full animate-pulse">
            <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-[#4a90e2] rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
          </div>
          <div className="absolute top-1/3 right-1/3 w-6 h-6 border border-[#4a90e2] animate-pulse delay-1000">
            <div className="absolute top-1/2 left-1/2 w-1 h-1 bg-[#4a90e2] transform -translate-x-1/2 -translate-y-1/2"></div>
          </div>
          <div className="absolute bottom-1/4 left-1/3 w-10 h-10 border border-[#4a90e2] rounded-full animate-pulse delay-2000">
            <div className="absolute top-1/2 left-1/2 w-3 h-3 bg-[#4a90e2] rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
          </div>
          <div className="absolute bottom-1/3 right-1/4 w-4 h-4 border border-[#4a90e2] animate-pulse delay-3000"></div>

          {/* Connecting lines */}
          <div className="absolute top-1/4 left-1/4 w-32 h-0.5 bg-[#4a90e2] transform rotate-45 animate-pulse delay-500"></div>
          <div className="absolute bottom-1/3 right-1/3 w-24 h-0.5 bg-[#4a90e2] transform -rotate-12 animate-pulse delay-1500"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen">
            {/* Left Column - Text Content */}
            <div className="space-y-8 animate-fade-in-left">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold font-heading">张晓东 (Mycroft ZHANG)</h1>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-medium text-[#a0a0a0] font-heading">
                Leveraging lipidomics and mass spectrometry to explore the mechanisms of natural products
              </h3>
              <p className="text-lg sm:text-xl text-[#a0a0a0]">PhD Applicant </p>

              {/* Contact Information */}
              <div className="space-y-4">
                <Link
                  href="mailto:ooazheng@163.com"
                  className="flex items-center gap-3 text-[#4a90e2] hover:text-[#e1e1e1] transition-colors text-lg"
                >
                  <Mail size={24} />
                  ooazheng@163.com
                </Link>
                <Link
                  href="tel:+8613228225275"
                  className="flex items-center gap-3 text-[#4a90e2] hover:text-[#e1e1e1] transition-colors text-lg"
                >
                  <Phone size={24} />
                  +86 13228225275
                </Link>
              </div>
            </div>

            {/* Right Column - Personal Photo */}
            <div className="flex justify-center animate-fade-in-right">
              <div className="w-96 h-96 rounded-lg overflow-hidden bg-[#2a2a2a] border-2 border-[#4a90e2]/20 flex items-center justify-center">
                <Image
                  src="/images/mycroft-profile.png"
                  alt="Mycroft Zhang - Professional Portrait"
                  width={384}
                  height={384}
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section - Two Column with Three Photos */}
      <section id="about" className="py-20 bg-[#1a1a1a]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Column - Text Content */}
            <div className="space-y-6 animate-fade-in-left">
              <h2 className="text-3xl sm:text-4xl font-bold mb-8 font-heading">About Me</h2>

              <p className="text-[#a0a0a0] leading-relaxed">
                "Hello, I'm Xiaodong Zhang, and you can also call me Mcroft. I am a highly motivated and proactive
                student, characterized by a rigorous and productive approach to scientific inquiry. My research
                experience is centered on leveraging LC-MS and bioinformatics to elucidate the complex chemical
                constituents and underlying mechanisms of natural products. While I maintain a serious and focused
                attitude towards my research, I am known for being a positive and approachable team member in daily
                collaborations."
              </p>

              <p className="text-[#a0a0a0] leading-relaxed">
                I hold a Master's degree in Chinese Materia Medica from Minzu University of China (GPA: 3.41/4.0) and a
                Bachelor's degree from Southwest Minzu University. During my studies in the State Key Laboratory Mass of
                Spectrometry Imaging and Metabolomics, I received rigorous scientific training, which equipped me with a
                solid theoretical foundation and the ability to independently design and execute complex experiments. I
                am highly self-motivated, adaptable, and adept at learning and summarizing from challenges.
              </p>

              <p className="text-[#a0a0a0] leading-relaxed">Outside the lab, I am a basketball and hiking person.</p>
            </div>

            {/* Right Column - Three Photos in Creative Layout */}
            <div className="relative animate-fade-in-right">
              <div className="grid grid-cols-2 gap-4 h-96">
                {/* Photo 1 - Academic/Work (Top Left) */}
                <div className="animate-fade-in-up">
                  <div className="w-full h-44 rounded-lg overflow-hidden bg-[#2a2a2a] border border-[#4a90e2]/20">
                    <Image
                      src="/images/lab-work.png"
                      alt="Laboratory Research Work"
                      width={200}
                      height={176}
                      className="object-cover w-full h-full"
                    />
                  </div>
                </div>

                {/* Photo 2 - Campus/Lab (Top Right) */}
                <div className="animate-fade-in-up delay-300">
                  <div className="w-full h-44 rounded-lg overflow-hidden bg-[#2a2a2a] border border-[#4a90e2]/20">
                    <Image
                      src="/images/outdoor-life.jpeg"
                      alt="Outdoor Adventures and Nature"
                      width={200}
                      height={176}
                      className="object-cover w-full h-full"
                    />
                  </div>
                </div>

                {/* Photo 3 - Life/Sports (Bottom Center, Spanning) */}
                <div className="col-span-2 animate-fade-in-up delay-500">
                  <div className="w-full h-44 rounded-lg overflow-hidden bg-[#2a2a2a] border border-[#4a90e2]/20">
                    <Image
                      src="/images/campus-life.jpeg"
                      alt="Campus Basketball Team"
                      width={400}
                      height={176}
                      className="object-cover w-full h-full"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Research Section */}
      <section id="research" className="py-20 bg-[#1a1a1a]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-bold mb-12 text-center font-heading">Research</h2>

          <div className="relative">
            <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-[#4a90e2]"></div>

            <div className="space-y-12">
              {/* Research Project 1 */}
              <Card className="ml-12 bg-[#2a2a2a] border-[#4a90e2]/20 hover:border-[#4a90e2]/40 transition-all duration-300 hover:transform hover:-translate-y-1 hover:shadow-lg hover:shadow-[#4a90e2]/10">
                <CardContent className="p-8">
                  <div className="absolute -left-16 top-8 w-4 h-4 bg-[#4a90e2] rounded-full"></div>
                  <div className="text-sm text-[#4a90e2] mb-2">2022.12 - 2024.01</div>
                  <h3 className="text-xl font-bold mb-4 font-heading">
                    Application of Lipidomics in the Anti-inflammatory Mechanisms of Natural Products
                  </h3>
                  <p className="text-[#a0a0a0] mb-4">Supervised by Professor Zeper Abliz</p>

                  <div className="flex flex-wrap gap-4 mb-6">
                    <div className="flex items-center gap-2 text-sm">
                      <FlaskConical size={16} className="text-[#4a90e2]" />
                      <span>Animal Model Construction</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <BarChart3 size={16} className="text-[#4a90e2]" />
                      <span>LC-MS Method Development</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Code size={16} className="text-[#4a90e2]" />
                      <span>R & Python Data Analysis</span>
                    </div>
                  </div>

                  <p className="text-[#a0a0a0] mb-6">
                    This project aimed to comprehensively analyze lipid alterations in the hypothalamus of a febrile
                    animal model using LC-MS to elucidate the anti-inflammatory mechanisms of natural products.
                  </p>

                  <div className="mb-6">
                    <h4 className="font-semibold mb-3 text-[#4a90e2]">Key Findings:</h4>
                    <ul className="list-disc list-inside space-y-2 text-[#a0a0a0]">
                      <li>
                        72 potential efficacy-related biomarkers were discovered and identified, including
                        phosphatidylcholine (PC), triacylglycerol (TG-O), and ceramide (Cer).
                      </li>
                      <li>
                        Our research elucidated the modulation of four key signaling pathways, including sphingolipid
                        and arachidonic acid metabolism, identifying COX-2 and PEMT as potential target proteins of
                        significant interest.
                      </li>
                    </ul>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-[#1a1a1a] p-4 rounded-lg">
                      <Image
                        src="/images/lcms-equipment.jpeg"
                        alt="LC-MS Equipment and Instrumentation"
                        width={300}
                        height={200}
                        className="w-full h-auto rounded"
                      />
                    </div>
                    <div className="bg-[#1a1a1a] p-4 rounded-lg">
                      <Image
                        src="/images/research-workflow.png"
                        alt="Research Workflow and Data Analysis Pipeline"
                        width={300}
                        height={200}
                        className="w-full h-auto rounded"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Research Project 2 */}
              <Card className="ml-12 bg-[#2a2a2a] border-[#4a90e2]/20 hover:border-[#4a90e2]/40 transition-all duration-300 hover:transform hover:-translate-y-1 hover:shadow-lg hover:shadow-[#4a90e2]/10">
                <CardContent className="p-8">
                  <div className="absolute -left-16 top-8 w-4 h-4 bg-[#4a90e2] rounded-full"></div>
                  <div className="text-sm text-[#4a90e2] mb-2">2022.01 - 2022.12</div>
                  <h3 className="text-xl font-bold mb-4 font-heading">
                    In Vivo Analysis of Natural Products via LC-MS
                  </h3>

                  <p className="text-[#a0a0a0] mb-6">
                    This research focused on establishing and optimizing an LC-MS method for the systematic analysis of
                    the in vivo metabolism of phenolic acids and flavonoids from natural products.
                  </p>

                  <div className="mb-6">
                    <h4 className="font-semibold mb-3 text-[#4a90e2]">Key Findings:</h4>
                    <ul className="list-disc list-inside space-y-2 text-[#a0a0a0]">
                      <li>Identified 18 parent compounds and 83 of their metabolites</li>
                      <li>
                        Elucidated key phase II and phase III metabolic reactions, including hydroxylation, methylation,
                        and isomerization
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Publications Section */}
      <section id="publications" className="py-20 bg-[#1a1a1a]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-bold mb-12 text-center font-heading">Publications</h2>

          <div className="space-y-8">
            <Card className="bg-[#2a2a2a] border-[#4a90e2]/20">
              <CardContent className="p-8">
                <div className="flex items-start justify-between mb-4">
                  <span className="text-2xl font-bold text-[#4a90e2]">1.</span>
                </div>
                <p className="text-[#e1e1e1] mb-6 leading-relaxed">
                  Zhang, X., Zhao, S., et al. (2024). Lipidomic profiling of the febrile rat hypothalamus by the
                  intervention of Artemisia japonica extracts. <em>J Pharm Biomed Anal</em>, 255, 116588.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Link href="https://doi.org/10.1016/j.jpba.2024.116588" target="_blank" rel="noopener noreferrer">
                    <Button className="bg-[#4a90e2] hover:bg-[#4a90e2]/80 text-white">
                      <ExternalLink size={16} className="mr-2" />
                      View Publication
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#2a2a2a] border-[#4a90e2]/20">
              <CardContent className="p-8">
                <div className="flex items-start justify-between mb-4">
                  <span className="text-2xl font-bold text-[#4a90e2]">2.</span>
                  <Badge variant="secondary" className="bg-[#4a90e2]/20 text-[#4a90e2]">
                    In preparation
                  </Badge>
                </div>
                <p className="text-[#e1e1e1] mb-6 leading-relaxed">
                  Cheng, S., Li, M., Zhang, X., et al. (2025). Comprehensive characterisation of multiple components...
                  <em>Journal of Chromatography A</em>.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-[#1a1a1a]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-bold mb-12 text-center font-heading">Skills</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-6 text-[#4a90e2] font-heading">Laboratory & Research</h3>
              <div className="flex flex-wrap gap-2">
                {[
                  "Animal Experiments",
                  "LC-MS Method Development",
                  "Mass Spectrometry Analysis",
                  "Lipidomics",
                  "Metabolomics",
                ].map((skill) => (
                  <Badge
                    key={skill}
                    variant="secondary"
                    className="bg-[#4a90e2]/20 text-[#4a90e2] hover:bg-[#4a90e2] hover:text-white transition-colors"
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-6 text-[#4a90e2] font-heading">Data & Programming</h3>
              <div className="flex flex-wrap gap-2">
                {["R (Multivariate Statistics)", "R (Data Visualization)", "Python (Data Processing)"].map((skill) => (
                  <Badge
                    key={skill}
                    variant="secondary"
                    className="bg-[#4a90e2]/20 text-[#4a90e2] hover:bg-[#4a90e2] hover:text-white transition-colors"
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-6 text-[#4a90e2] font-heading">Software & Tools</h3>
              <div className="flex flex-wrap gap-2">
                {["Adobe Illustrator", "ChemDraw", "Graphpad Prism", "MS-DIAL"].map((skill) => (
                  <Badge
                    key={skill}
                    variant="secondary"
                    className="bg-[#4a90e2]/20 text-[#4a90e2] hover:bg-[#4a90e2] hover:text-white transition-colors"
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-6 text-[#4a90e2] font-heading">Languages</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span>Chinese (Mandarin)</span>
                    <span className="text-[#a0a0a0]">Native</span>
                  </div>
                  <Progress value={100} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span>English</span>
                    <span className="text-[#a0a0a0]">IELTS 6.0</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-[#1a1a1a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-8 font-heading">Get In Touch</h2>

          <p className="text-xl text-[#a0a0a0] mb-12 leading-relaxed">
            I am currently seeking PhD opportunities and am eager to contribute to innovative research in Multi-omics
            and natural product chemistry. Please feel free to reach out if you'd like to discuss potential
            collaborations or positions.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link
              href="mailto:ooazheng@163.com"
              className="flex items-center gap-3 text-[#4a90e2] hover:text-[#e1e1e1] transition-colors text-lg"
            >
              <Mail size={24} />
              ooazheng@163.com
            </Link>

            <Link
              href="tel:+8613228225275"
              className="flex items-center gap-3 text-[#4a90e2] hover:text-[#e1e1e1] transition-colors text-lg"
            >
              <Phone size={24} />
              +86 13228225275
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-[#4a90e2]/20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-[#a0a0a0]">© 2025 Mycroft Zhang. </p>
        </div>
      </footer>
    </div>
  )
}
